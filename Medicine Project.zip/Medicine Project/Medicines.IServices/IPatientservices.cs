﻿using Medicines.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medicines.IServices
{
    public interface IPatientService
    {
        Task<int> AddAsync(PatientDetails patientDetailsList);  // Changed the return type to Task<int>
        // Add other methods as needed for patient-related operations
        Task<bool> AddBulkAsync(List<MedicinesDetails> medicinesDetailsList);
    }
}
