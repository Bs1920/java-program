﻿using Medicines.IRepository;
using Medicines.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace Medicines.Repository
{
    public class PatientRepository : IPatientRepository
    {
        private readonly IConfiguration _configuration;

        public PatientRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public async Task<int> AddAsync(PatientDetails patientDetailsList)
        {
            try
            {
                string connectionString = _configuration.GetConnectionString("DbConnection");
                using (IDbConnection db = new SqlConnection(connectionString))
                {
                    var parameters = new DynamicParameters();

                    parameters.Add("@Bill_No", patientDetailsList.Bill_No);
                    parameters.Add("@Patient_Name", patientDetailsList.Patient_Name);
                    parameters.Add("@NewlyInsertedId", dbType: DbType.Int32, direction: ParameterDirection.Output);

                    await db.ExecuteAsync("dbo.InserPatient", parameters, commandType: CommandType.StoredProcedure);

                    // Retrieve the value of the OUTPUT parameter
                    int insertedPatientId = parameters.Get<int>("@NewlyInsertedId");

                    // Return the ID of the newly inserted patient
                    return insertedPatientId;
                }
            }
            catch (Exception ex)
            {
                // Log or handle the exception appropriately
                throw;
            }
        }


        public async Task<bool> AddBulkAsync(List<MedicinesDetails> medicinesDetailsList)
        {
            try
            {
                string connectionString = _configuration.GetConnectionString("DbConnection");
                using (IDbConnection db = new SqlConnection(connectionString))
                {
                    foreach (var medicineDetails in medicinesDetailsList)
                    {
                        var parameters = new DynamicParameters();

                        parameters.Add("@Medicines_Name", medicineDetails.Medicines_Name);
                        parameters.Add("@Medicines_Price", medicineDetails.Medicines_Price);

                        // Assuming there is an additional parameter for Bill_Id, adjust accordingly
                        parameters.Add("@Bill_Id", medicineDetails.Bill_Id);

                        await db.ExecuteAsync("dbo.InsertMedicine", parameters, commandType: CommandType.StoredProcedure);
                    }

                    return true;  // Return true if all items are successfully inserted
                }
            }
            catch (Exception ex)
            {
                // Log or handle the exception appropriately
                return false;  // Return false if there's an exception during the process
            }
        }

    }
}
