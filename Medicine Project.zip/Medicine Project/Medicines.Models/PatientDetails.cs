﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medicines.Models
{
    public class PatientDetails
    {
        public int Bill_Id { get; set; }

        [Required(ErrorMessage = "Bill No is required.")]
        [StringLength(10, ErrorMessage = "Bill No must be at most 10 characters.")]
        public string Bill_No { get; set; }

        [Required(ErrorMessage = "Patient Name is required.")]
        [StringLength(50, ErrorMessage = "Patient Name must be at most 50 characters.")]
        public string Patient_Name { get; set; }

        //public List<MedicinesDetails> Medicines { get; set; }
    }
}
