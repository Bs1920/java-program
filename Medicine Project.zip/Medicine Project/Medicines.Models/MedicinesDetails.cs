﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medicines.Models
{
    public class MedicinesDetails
    {
        public int Medicines_Id { get; set; }

        [Required(ErrorMessage = "Medicine Name is required.")]
        [StringLength(50, ErrorMessage = "Medicine Name must be at most 50 characters.")]
        public string Medicines_Name { get; set; }
        public int Bill_Id { get; set; }

        [Range(0.01, double.MaxValue, ErrorMessage = "Medicine Price must be greater than 0.")]
        public decimal Medicines_Price { get; set; }

        //public PatientDetails Patient { get; set; }
    }
}
