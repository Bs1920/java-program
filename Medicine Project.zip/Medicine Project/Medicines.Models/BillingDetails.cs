﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medicines.Models
{
    public class BillingDetails
    {
        public PatientDetails PatientDetailsList { get; set; }
        public String MedicinesDetailsList { get; set; }
    }
}
