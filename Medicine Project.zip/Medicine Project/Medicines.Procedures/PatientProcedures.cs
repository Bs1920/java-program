﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medicines.Procedures
{
    internal class PatientProcedures
    {
        public static string InsertPatient = "dbo.InserPatient";

        public static string InsertMedicines = "dbo.InsertMedicine";
    }
}
