﻿using Medicines.IRepository;
using Medicines.IServices;
using Medicines.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Medicines.Services
{
    public class PatientService : IPatientService
    {
        private readonly IPatientRepository _patientRepository;

        public PatientService(IPatientRepository patientRepository)
        {
            _patientRepository = patientRepository;
        }

        public async Task<int> AddAsync(PatientDetails patientDetailsList)
        {
            // Assuming your repository returns an identifier (e.g., patient ID) after adding the patient details
            return await _patientRepository.AddAsync(patientDetailsList);
        }

        public async Task<bool> AddBulkAsync(List<MedicinesDetails> medicinesDetailsList)
        {
            return await _patientRepository.AddBulkAsync(medicinesDetailsList);
        }
    }
}
