﻿using Medicines.IServices;
using Medicines.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Threading.Tasks;

namespace Medicines.Controllers
{
    public class PatientController : Controller
    {
        private readonly IPatientService _patientService; // Assuming you have a service interface

        public PatientController(IPatientService patientService)
        {
            _patientService = patientService;
        }

        public IActionResult Create()
        {
            // Return the create view
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CreateAsync(BillingDetails billingDetails)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    int savedPatientId = await _patientService.AddAsync(billingDetails.PatientDetailsList);

                    if (savedPatientId > 0)
                    {
                        List<MedicinesDetails> patientValues = JsonConvert.DeserializeObject<List<MedicinesDetails>>(billingDetails.MedicinesDetailsList);
                                               
                        if (patientValues != null)
                        {                           
                            patientValues = patientValues.Select(pv => new MedicinesDetails
                            {
                                Medicines_Name = pv.Medicines_Name,
                                Medicines_Price = pv.Medicines_Price,
                                Bill_Id = savedPatientId, // Use the savedPatientId as Bill_Id
                            }).ToList();
                                                       
                            if (patientValues.Count > 0)
                            {                                
                                bool isSuccess = await _patientService.AddBulkAsync(patientValues);

                                if (isSuccess)
                                {
                                    return View(billingDetails);
                                }
                            }
                        }
                    }
                    else
                    {                       
                        return View(billingDetails);
                    }
                }
                return View(billingDetails);
            }
            catch (Exception ex)
            {
              
                return View(billingDetails);
            }
        }
    }
}
